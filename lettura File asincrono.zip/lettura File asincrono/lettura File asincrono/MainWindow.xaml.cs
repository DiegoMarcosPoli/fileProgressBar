﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace lettura_File_asincrono
{
    /// <summary>
    /// Logica di interazione per MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int i = 0;
        Random r;
        int caratteri = 0;
        public MainWindow()
        {
            InitializeComponent();
            r = new Random();
            LeggiFile();
            BarraProgressi();
        }
        public async void LeggiFile()
        {
            await Task.Run(() =>
            {
                using (StreamReader lettore = new StreamReader("Data.txt"))
                {
                   
                    while (!lettore.EndOfStream)
                    {
                        Thread.Sleep(r.Next(0, 301));
                        string riga = lettore.ReadLine();
                        caratteri += riga.Length;
                    }
                }
                while (true)
                {
                    if (i == 100)
                    {
                        MessageBox.Show("I caratteri presenti nel file sono: " + caratteri);
                        break;
                        
                    }                   
                }
            });

        }
        public async void BarraProgressi()
        {

            await Task.Run(() =>
            {
                while (i < 100)
                {
                    
                    Thread.Sleep(r.Next(0, 301));
                    this.Dispatcher.BeginInvoke(new Action(() =>
                    {
                        barraProgressi.Value++;
                    }));
                    i++;
                }
            });
        }
    }
}
